from learner.models.save_load import load_kernel_model


model = load_kernel_model("understanding_features.model")


print(f"Initial ILG colours and their semantic meanings")
init_colours_and_descriptions = model.get_initial_colour_descriptions(
    "blocksworld"
)
for k, v in init_colours_and_descriptions.items():
    print(f"{k:>3} -> {v}")


print("Studied features to decompressed meaning and weight")
f_to_weight = model.get_features_sorted_by_weight()
decompress = model.get_reverse_feature_hash()
studied_features = [3, 0, 11, 16, 179, 181, 186, 182, 193]
for i, f in enumerate(studied_features):
    weight = f"{f_to_weight[decompress[f]]:.10f}"
    print(f"c_{i} = {f:>3} -> {decompress[f]:>20}; weight : {weight:>13}")


print("Sum of weights of features c_4, c_6, c_7, c_8:")
equiv_features = [179, 186, 182, 193]
weight = sum(f_to_weight[decompress[feature]] for feature in equiv_features)
print(weight)


print(f"Top 5 weights (sum of weights of features with the same weight):")
weights = model.get_weights()
weight_cnts = {}
for w in f_to_weight.values():
    if w not in weight_cnts:
        weight_cnts[w] = 0
    weight_cnts[w] += 1
weights = [w * c for w, c in weight_cnts.items()]
weights = sorted(weights, reverse=True, key=lambda x: abs(x))
print(weights[:5])
